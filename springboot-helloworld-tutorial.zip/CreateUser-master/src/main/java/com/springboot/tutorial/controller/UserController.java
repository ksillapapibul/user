package com.springboot.tutorial.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.springboot.tutorial.entity.User;
import com.springboot.tutorial.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService service;
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		List<User> employeeList = service.listAll();
		model.addAttribute("listAll", employeeList);
		return "index";
	}
	
	@RequestMapping("/new")
	public String showNewEmployeePage(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "new_user";
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveEmployee(@ModelAttribute("user") User user,Model model,BindingResult result) {
		service.save(user);
		List<User> userList = service.listAll();
		model.addAttribute("listAll", userList);
		model.addAttribute("userAttr",user);
		return "index";
	}
}
