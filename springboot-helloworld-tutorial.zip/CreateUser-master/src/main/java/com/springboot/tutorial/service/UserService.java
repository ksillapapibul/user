package com.springboot.tutorial.service;

import java.util.List;
import com.springboot.tutorial.entity.User;
public interface UserService {

	List<User> listAll();

	void save(User user);

}
